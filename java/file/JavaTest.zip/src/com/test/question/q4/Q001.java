package com.test.question.q4;

public class Q001 {
	public static void main(String[] args) {
	
	hello();
	introduce();
	bye();
	
}//main

public static void hello() {
	System.out.println("안녕하세요.");
}

public static void introduce() {
	System.out.println("저는 홍길동입니다.");
}

public static void bye() {
	System.out.println("안녕히가세요.");
}


}

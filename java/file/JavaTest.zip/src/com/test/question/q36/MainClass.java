package com.test.question.q36;

public class MainClass {
	
	public static void main(String[] args) {
		
		Box box1 = new Box();
		
		box1.cook();
		box1.check();
		box1.list();
		
		
		
	}
	
}

package aaa;

public class practice01 {
	public static void main(String[] args) 
    {

        //요구사항] 정수형 타입의 변수를 만들어 초기화를 하고 그 값을 출력하시오.
        int a = 10;
        int b;

        System.out.println("a : " + a)
        System.out.println("b : " + b);
        System.out.println("c : " + c);


        //요구사항] 학생의 이름과 키와 몸무게를 출력하시오.
        String name = "홍길동";
        int height = 180;
        int weight = 72;

        System.out.printf("학생 이름 : %s\n", name);
        System.out.printf("학생 키 : %dcm\n", name);
        System.out.printf("학생 몸무게 : %dkg\n", weight);

    } //main

}

}
